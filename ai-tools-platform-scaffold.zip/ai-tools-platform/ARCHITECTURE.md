# AI Tools Platform — Architecture

## Stack decisions
- **Next.js 15 App Router**, React 19, Turbopack dev server. Partial Prerendering (`ppr: incremental`) so directory pages are static-shell fast while search/personalized bits stream in.
- **Supabase**: Postgres + Auth + Storage. Row Level Security is the authorization layer — not just app-level checks — so data stays safe even if an API route has a bug.
- **TypeScript strict mode** everywhere, generated DB types (`types/database.ts`) from the live schema so query results are fully typed.
- **Tailwind + CSS variables** for theming: dark mode via `next-themes` class strategy, no flash-of-wrong-theme.
- Server Components by default; Client Components only where interactivity is required (search box, forms, admin tables, theme toggle).

## Folder structure
```
app/
  (marketing)/         # /about, /contact — static marketing pages, own layout
  (main)/               # public site, shares header/footer layout
    tools/[slug]/        # tool detail page
    categories/[category]/
    search/              # search UI (client component + server actions)
    blog/[slug]/
    news/[slug]/
    deals/
    prompts/[slug]/
    generators/[slug]/
  (auth)/               # /login, /register — minimal layout, no header/footer
  admin/                # dashboard, gated by middleware, role-checked via profiles.role
    tools/ blog/ news/ deals/ prompts/ generators/ users/ analytics/
  api/                  # route handlers: search, revalidate, cron, admin mutations
components/
  ui/                   # design-system primitives (button, card, input, dialog...)
  layout/               # header, footer, theme provider, mobile nav
  tools/ blog/ news/ deals/ prompts/ generators/ admin/  # feature-specific components
  shared/                # things reused across features (pagination, tag-pill, empty-state)
lib/
  supabase/              # client.ts (browser), server.ts (RSC/actions), middleware.ts (session refresh)
  db/                    # typed query functions (getToolBySlug, listToolsByCategory, ...)
  validations/           # zod schemas — shared between forms and API routes
  seo/                   # metadata builders, JSON-LD generators
  ai/                    # server-only calls to LLM providers for the free generators
  utils/                 # cn(), formatting, slugify
types/                   # database.ts (generated) + hand-written domain types
supabase/
  migrations/            # SQL migrations, source of truth for schema
  seed/                  # seed data for local dev
config/                  # site.ts (nav, metadata), nav/category constants
```

## Why route groups
`(marketing)`, `(main)`, `(auth)` are route groups — they don't affect the URL, only let each area have its own `layout.tsx` (e.g. auth pages skip the main header/footer; admin has a completely separate shell under `/admin`).

## Data flow
1. **Public pages** (tools, blog, news, deals, prompts, generators) are Server Components that call typed functions in `lib/db/` which use the anon Supabase client — RLS restricts them to `status = 'published'` rows automatically.
2. **Search** hits a Postgres full-text index (`tools_search_idx`, GIN + `pg_trgm`) via a route handler (`/api/search`) so it works well with typeahead and is fast without a separate search service. Can swap in Algolia/Meilisearch later without touching the schema.
3. **Admin dashboard** writes go through Server Actions or `/api/admin/*` route handlers using the **service-role client**, after verifying `profiles.role in ('admin','editor')`. Middleware also blocks `/admin/*` at the edge for unauthenticated/non-staff users.
4. **ISR + on-demand revalidation**: content pages are statically generated and revalidated via `/api/revalidate` (called from the admin dashboard on publish) rather than long time-based revalidation, so edits go live instantly without sacrificing static performance.
5. **Free generators** call `lib/ai/` server-side (API keys never touch the client), log usage to `generator_usage_logs` for rate-limiting/abuse prevention via Upstash Redis.

## SEO approach
- Per-page `generateMetadata` using `lib/seo/` helpers (title templates, canonical URLs, OG images).
- JSON-LD structured data: `SoftwareApplication` schema on tool pages, `Article` on blog/news, `BreadcrumbList` site-wide.
- `sitemap.ts` and `robots.ts` at the `app/` root (dynamic, generated from published content).
- Semantic HTML, single `h1` per page, descriptive alt text enforced in the CMS forms.

## Performance
- Static generation + PPR for directory/listing pages; streaming with `<Suspense>` for personalized widgets (upvote state, "saved" bookmarks).
- `next/image` with AVIF/WebP, Supabase Storage as the image origin.
- Route-level code splitting is automatic; heavy admin-only libraries (rich text editor, charts) are dynamically imported so they never bloat the public bundle.

## What's built so far (this step)
- Full folder scaffold
- `package.json`, `tsconfig.json`, `tailwind.config.ts`, `next.config.ts`
- Supabase browser/server/middleware clients + root `middleware.ts` (admin route protection)
- Initial Postgres schema + RLS policies (`supabase/migrations/00000000000001_init.sql`)
- Root layout with metadata, dark mode provider, global design tokens
- Site config (`config/site.ts`)

## Suggested build order (next steps)
1. `types/database.ts` (generated) + `lib/db/tools.ts` typed query layer
2. Design-system primitives in `components/ui/` (Button, Card, Input, Badge, Skeleton)
3. Header/Footer + homepage
4. Tools directory: categories page, tool detail page, search
5. Auth (login/register) + `profiles` role wiring
6. Blog, News, Deals, Prompts (mostly the same CRUD + rendering pattern)
7. Free AI Generators (form → server action → LLM call → result)
8. Admin Dashboard (tables, forms, publish/revalidate flow)
9. SEO pass: sitemap.ts, robots.ts, JSON-LD, OG image generation
10. Performance pass + deployment (Vercel + Supabase production project)
