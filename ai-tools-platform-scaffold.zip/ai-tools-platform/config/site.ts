export const siteConfig = {
  name: "AI Tools Hub",
  description:
    "Discover, compare, and use the best AI tools — with daily AI news, deals, prompts, and free generators.",
  url: process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000",
  ogImage: "/images/og-default.png",
  links: {
    twitter: "https://twitter.com/yourhandle",
    github: "https://github.com/yourhandle",
  },
  nav: [
    { title: "Tools", href: "/tools" },
    { title: "Categories", href: "/categories" },
    { title: "News", href: "/news" },
    { title: "Deals", href: "/deals" },
    { title: "Prompts", href: "/prompts" },
    { title: "Generators", href: "/generators" },
    { title: "Blog", href: "/blog" },
  ],
} as const;

export type SiteConfig = typeof siteConfig;
