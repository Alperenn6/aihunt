-- ============================================================================
-- AI Tools Platform — Initial Schema
-- ============================================================================
create extension if not exists "uuid-ossp";
create extension if not exists pg_trgm;   -- fuzzy/fast text search

create type content_status as enum ('draft', 'published', 'archived');
create type pricing_model as enum ('free', 'freemium', 'paid', 'trial', 'open_source');

-- ----------------------------------------------------------------------------
-- Categories (self-referencing for sub-categories)
-- ----------------------------------------------------------------------------
create table categories (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  slug text not null unique,
  description text,
  icon text,
  parent_id uuid references categories(id) on delete set null,
  sort_order int default 0,
  created_at timestamptz not null default now()
);

-- ----------------------------------------------------------------------------
-- AI Tools (the core directory entity)
-- ----------------------------------------------------------------------------
create table tools (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  slug text not null unique,
  tagline text,
  description text,
  website_url text not null,
  logo_url text,
  screenshots text[] default '{}',
  pricing pricing_model not null default 'free',
  pricing_details text,
  category_id uuid references categories(id) on delete set null,
  tags text[] default '{}',
  status content_status not null default 'draft',
  is_featured boolean not null default false,
  upvotes int not null default 0,
  views int not null default 0,
  avg_rating numeric(2,1) default 0,
  review_count int not null default 0,
  meta_title text,
  meta_description text,
  submitted_by uuid references auth.users(id) on delete set null,
  published_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index tools_category_idx on tools(category_id);
create index tools_status_idx on tools(status);
create index tools_tags_idx on tools using gin(tags);
create index tools_search_idx on tools using gin (
  (setweight(to_tsvector('english', coalesce(name,'')), 'A') ||
   setweight(to_tsvector('english', coalesce(tagline,'')), 'B') ||
   setweight(to_tsvector('english', coalesce(description,'')), 'C'))
);
create index tools_name_trgm_idx on tools using gin (name gin_trgm_ops);

create table tool_reviews (
  id uuid primary key default uuid_generate_v4(),
  tool_id uuid not null references tools(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  rating int not null check (rating between 1 and 5),
  comment text,
  created_at timestamptz not null default now(),
  unique (tool_id, user_id)
);

create table tool_upvotes (
  tool_id uuid not null references tools(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (tool_id, user_id)
);

-- ----------------------------------------------------------------------------
-- Blog
-- ----------------------------------------------------------------------------
create table blog_posts (
  id uuid primary key default uuid_generate_v4(),
  title text not null,
  slug text not null unique,
  excerpt text,
  content_mdx text not null,
  cover_image text,
  author_id uuid references auth.users(id) on delete set null,
  tags text[] default '{}',
  status content_status not null default 'draft',
  meta_title text,
  meta_description text,
  reading_time_minutes int,
  published_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index blog_status_idx on blog_posts(status, published_at desc);

-- ----------------------------------------------------------------------------
-- AI News
-- ----------------------------------------------------------------------------
create table news_articles (
  id uuid primary key default uuid_generate_v4(),
  title text not null,
  slug text not null unique,
  summary text,
  content_mdx text not null,
  source_name text,
  source_url text,
  cover_image text,
  category text,
  status content_status not null default 'draft',
  published_at timestamptz,
  created_at timestamptz not null default now()
);
create index news_status_idx on news_articles(status, published_at desc);

-- ----------------------------------------------------------------------------
-- AI Deals
-- ----------------------------------------------------------------------------
create table deals (
  id uuid primary key default uuid_generate_v4(),
  tool_id uuid references tools(id) on delete cascade,
  title text not null,
  slug text not null unique,
  description text,
  discount_percent int,
  promo_code text,
  affiliate_url text not null,
  starts_at timestamptz,
  expires_at timestamptz,
  status content_status not null default 'draft',
  created_at timestamptz not null default now()
);
create index deals_active_idx on deals(status, expires_at);

-- ----------------------------------------------------------------------------
-- Prompt Library
-- ----------------------------------------------------------------------------
create table prompts (
  id uuid primary key default uuid_generate_v4(),
  title text not null,
  slug text not null unique,
  body text not null,
  description text,
  category text,
  target_model text,             -- e.g. "ChatGPT", "Midjourney", "Claude"
  tags text[] default '{}',
  copy_count int not null default 0,
  status content_status not null default 'draft',
  created_at timestamptz not null default now()
);
create index prompts_tags_idx on prompts using gin(tags);

-- ----------------------------------------------------------------------------
-- Free AI Generators (metadata only — logic lives in app/api/generators)
-- ----------------------------------------------------------------------------
create table generators (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  slug text not null unique,
  description text,
  input_schema jsonb not null default '{}',   -- drives dynamic form rendering
  icon text,
  usage_count int not null default 0,
  status content_status not null default 'draft',
  created_at timestamptz not null default now()
);

create table generator_usage_logs (
  id uuid primary key default uuid_generate_v4(),
  generator_id uuid references generators(id) on delete cascade,
  user_id uuid references auth.users(id) on delete set null,
  ip_hash text,
  created_at timestamptz not null default now()
);

-- ----------------------------------------------------------------------------
-- Admin roles
-- ----------------------------------------------------------------------------
create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  avatar_url text,
  role text not null default 'user' check (role in ('user', 'editor', 'admin')),
  created_at timestamptz not null default now()
);

-- ============================================================================
-- Row Level Security
-- ============================================================================
alter table tools enable row level security;
alter table blog_posts enable row level security;
alter table news_articles enable row level security;
alter table deals enable row level security;
alter table prompts enable row level security;
alter table generators enable row level security;
alter table tool_reviews enable row level security;
alter table tool_upvotes enable row level security;
alter table profiles enable row level security;

-- Public can read published content only
create policy "public_read_published_tools" on tools for select using (status = 'published');
create policy "public_read_published_blog" on blog_posts for select using (status = 'published');
create policy "public_read_published_news" on news_articles for select using (status = 'published');
create policy "public_read_published_deals" on deals for select using (status = 'published');
create policy "public_read_published_prompts" on prompts for select using (status = 'published');
create policy "public_read_published_generators" on generators for select using (status = 'published');

-- Reviews: anyone can read, only owner can write/edit their own
create policy "public_read_reviews" on tool_reviews for select using (true);
create policy "user_insert_own_review" on tool_reviews for insert with check (auth.uid() = user_id);
create policy "user_update_own_review" on tool_reviews for update using (auth.uid() = user_id);

create policy "public_read_upvotes" on tool_upvotes for select using (true);
create policy "user_manage_own_upvote" on tool_upvotes for all using (auth.uid() = user_id);

-- Profiles: users read/update their own row
create policy "user_read_own_profile" on profiles for select using (auth.uid() = id);
create policy "user_update_own_profile" on profiles for update using (auth.uid() = id);

-- Admin/editor full access (checked via profiles.role) on every content table
create policy "staff_full_access_tools" on tools for all
  using (exists (select 1 from profiles p where p.id = auth.uid() and p.role in ('admin','editor')));
create policy "staff_full_access_blog" on blog_posts for all
  using (exists (select 1 from profiles p where p.id = auth.uid() and p.role in ('admin','editor')));
create policy "staff_full_access_news" on news_articles for all
  using (exists (select 1 from profiles p where p.id = auth.uid() and p.role in ('admin','editor')));
create policy "staff_full_access_deals" on deals for all
  using (exists (select 1 from profiles p where p.id = auth.uid() and p.role in ('admin','editor')));
create policy "staff_full_access_prompts" on prompts for all
  using (exists (select 1 from profiles p where p.id = auth.uid() and p.role in ('admin','editor')));
create policy "staff_full_access_generators" on generators for all
  using (exists (select 1 from profiles p where p.id = auth.uid() and p.role in ('admin','editor')));

-- Auto-create a profile row on signup
create function public.handle_new_user() returns trigger as $$
begin
  insert into public.profiles (id, full_name) values (new.id, new.raw_user_meta_data->>'full_name');
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();
